--
-- PostgreSQL database dump
--

\restrict Xb4ksDJywjseMWwFgUt6UlntsyMOt1kJZzek0Nc90v6KM462yBBVi81wKffVDlr

-- Dumped from database version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.teacher_payment DROP CONSTRAINT IF EXISTS teacher_payment_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscription_payment DROP CONSTRAINT IF EXISTS subscription_payment_subscription_id_fkey;
ALTER TABLE IF EXISTS ONLY public.student_groups DROP CONSTRAINT IF EXISTS student_groups_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.student_groups DROP CONSTRAINT IF EXISTS student_groups_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_head_teacher_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_students DROP CONSTRAINT IF EXISTS course_students_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.competition_scores DROP CONSTRAINT IF EXISTS competition_scores_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.competition_scores DROP CONSTRAINT IF EXISTS competition_scores_student_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.competition_scores DROP CONSTRAINT IF EXISTS competition_scores_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.absences DROP CONSTRAINT IF EXISTS absences_student_id_fkey;
DROP INDEX IF EXISTS public.uq_competition_year_member;
DROP INDEX IF EXISTS public.teacher_payment_teacher_id_year_month;
DROP INDEX IF EXISTS public.subscription_payment_subscription_id_year_month;
DROP INDEX IF EXISTS public.student_groups_student_id_group_id_year;
DROP INDEX IF EXISTS public.student_groups_student_id_group_id;
DROP INDEX IF EXISTS public.student_groups_group_id_year;
DROP INDEX IF EXISTS public.idx_competition_year_group;
DROP INDEX IF EXISTS public.activities_start_date;
DROP INDEX IF EXISTS public.activities_name;
DROP INDEX IF EXISTS public.activities_end_date;
DROP INDEX IF EXISTS public.absences_student_id_date;
DROP INDEX IF EXISTS public.absences_student_id;
DROP INDEX IF EXISTS public.absences_date;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.teachers DROP CONSTRAINT IF EXISTS teachers_pkey;
ALTER TABLE IF EXISTS ONLY public.teacher_payment DROP CONSTRAINT IF EXISTS teacher_payment_pkey;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_payment DROP CONSTRAINT IF EXISTS subscription_payment_pkey;
ALTER TABLE IF EXISTS ONLY public.students DROP CONSTRAINT IF EXISTS students_pkey;
ALTER TABLE IF EXISTS ONLY public.student_groups DROP CONSTRAINT IF EXISTS student_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_pkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS donations_pkey;
ALTER TABLE IF EXISTS ONLY public.courses DROP CONSTRAINT IF EXISTS courses_pkey;
ALTER TABLE IF EXISTS ONLY public.course_students DROP CONSTRAINT IF EXISTS course_students_pkey;
ALTER TABLE IF EXISTS ONLY public.competition_scores DROP CONSTRAINT IF EXISTS competition_scores_pkey;
ALTER TABLE IF EXISTS ONLY public.activities DROP CONSTRAINT IF EXISTS activities_pkey;
ALTER TABLE IF EXISTS ONLY public.absences DROP CONSTRAINT IF EXISTS absences_pkey;
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key9";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key8";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key75";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key74";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key73";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key72";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key71";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key70";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key7";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key69";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key68";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key67";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key66";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key65";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key64";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key63";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key62";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key61";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key60";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key6";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key59";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key58";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key57";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key56";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key55";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key54";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key53";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key52";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key51";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key50";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key5";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key49";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key48";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key47";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key46";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key45";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key44";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key43";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key42";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key41";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key40";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key4";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key39";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key38";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key37";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key36";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key35";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key34";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key33";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key32";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key31";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key30";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key3";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key29";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key28";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key27";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key26";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key25";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key24";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key23";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key22";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key21";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key20";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key2";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key19";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key18";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key17";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key16";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key15";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key14";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key13";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key12";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key11";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key10";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key1";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_user_id_key";
ALTER TABLE IF EXISTS ONLY public."GoogleTokens" DROP CONSTRAINT IF EXISTS "GoogleTokens_pkey";
ALTER TABLE IF EXISTS ONLY public."BackupLogs" DROP CONSTRAINT IF EXISTS "BackupLogs_pkey";
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.teachers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.teacher_payment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.subscriptions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.subscription_payment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.students ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.student_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.expenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.donations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.courses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.competition_scores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.activities ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.absences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public."GoogleTokens" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public."BackupLogs" ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.teachers_id_seq;
DROP TABLE IF EXISTS public.teachers;
DROP SEQUENCE IF EXISTS public.teacher_payment_id_seq;
DROP TABLE IF EXISTS public.teacher_payment;
DROP SEQUENCE IF EXISTS public.subscriptions_id_seq;
DROP TABLE IF EXISTS public.subscriptions;
DROP SEQUENCE IF EXISTS public.subscription_payment_id_seq;
DROP TABLE IF EXISTS public.subscription_payment;
DROP SEQUENCE IF EXISTS public.students_id_seq;
DROP TABLE IF EXISTS public.students;
DROP SEQUENCE IF EXISTS public.student_groups_id_seq;
DROP TABLE IF EXISTS public.student_groups;
DROP SEQUENCE IF EXISTS public.settings_id_seq;
DROP TABLE IF EXISTS public.settings;
DROP SEQUENCE IF EXISTS public.groups_id_seq;
DROP TABLE IF EXISTS public.groups;
DROP SEQUENCE IF EXISTS public.expenses_id_seq;
DROP TABLE IF EXISTS public.expenses;
DROP SEQUENCE IF EXISTS public.donations_id_seq;
DROP TABLE IF EXISTS public.donations;
DROP SEQUENCE IF EXISTS public.courses_id_seq;
DROP TABLE IF EXISTS public.courses;
DROP TABLE IF EXISTS public.course_students;
DROP SEQUENCE IF EXISTS public.competition_scores_id_seq;
DROP TABLE IF EXISTS public.competition_scores;
DROP SEQUENCE IF EXISTS public.activities_id_seq;
DROP TABLE IF EXISTS public.activities;
DROP SEQUENCE IF EXISTS public.absences_id_seq;
DROP TABLE IF EXISTS public.absences;
DROP SEQUENCE IF EXISTS public."GoogleTokens_id_seq";
DROP TABLE IF EXISTS public."GoogleTokens";
DROP SEQUENCE IF EXISTS public."BackupLogs_id_seq";
DROP TABLE IF EXISTS public."BackupLogs";
DROP TYPE IF EXISTS public.enum_users_role;
DROP TYPE IF EXISTS public.enum_subscription_payment_status;
DROP TYPE IF EXISTS public.enum_student_groups_type;
DROP TYPE IF EXISTS public.enum_donations_kind;
DROP TYPE IF EXISTS public.enum_donations_donor_type;
DROP TYPE IF EXISTS public.enum_courses_status;
DROP TYPE IF EXISTS public."enum_BackupLogs_status";
--
-- Name: enum_BackupLogs_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."enum_BackupLogs_status" AS ENUM (
    'success',
    'running',
    'error'
);


--
-- Name: enum_courses_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_courses_status AS ENUM (
    'active',
    'finish'
);


--
-- Name: enum_donations_donor_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_donations_donor_type AS ENUM (
    'person',
    'organization',
    'anonymous'
);


--
-- Name: enum_donations_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_donations_kind AS ENUM (
    'money',
    'in_kind'
);


--
-- Name: enum_student_groups_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_student_groups_type AS ENUM (
    'student',
    'stranger'
);


--
-- Name: enum_subscription_payment_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_subscription_payment_status AS ENUM (
    'pay',
    'part'
);


--
-- Name: enum_users_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_users_role AS ENUM (
    'كاتب(ة)',
    'كاتب)',
    'كاتب',
    'مدير',
    'supervisor',
    'admin'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: BackupLogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BackupLogs" (
    id integer NOT NULL,
    filename character varying(255) NOT NULL,
    size bigint DEFAULT 0,
    status public."enum_BackupLogs_status" DEFAULT 'running'::public."enum_BackupLogs_status",
    uploaded_to_drive boolean DEFAULT false,
    error text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: BackupLogs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."BackupLogs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: BackupLogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."BackupLogs_id_seq" OWNED BY public."BackupLogs".id;


--
-- Name: GoogleTokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GoogleTokens" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    refresh_token text NOT NULL,
    email character varying(255),
    folder_id character varying(255),
    last_upload_at timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: GoogleTokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."GoogleTokens_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: GoogleTokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."GoogleTokens_id_seq" OWNED BY public."GoogleTokens".id;


--
-- Name: absences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.absences (
    id bigint NOT NULL,
    student_id bigint NOT NULL,
    date date NOT NULL,
    justified boolean DEFAULT false NOT NULL,
    reason character varying(255) DEFAULT NULL::character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: absences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.absences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: absences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.absences_id_seq OWNED BY public.absences.id;


--
-- Name: activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activities (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: competition_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.competition_scores (
    id integer NOT NULL,
    year integer NOT NULL,
    group_id bigint NOT NULL,
    student_group_id bigint NOT NULL,
    score numeric(5,2) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    student_id bigint
);


--
-- Name: competition_scores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.competition_scores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: competition_scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.competition_scores_id_seq OWNED BY public.competition_scores.id;


--
-- Name: course_students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.course_students (
    course_id bigint NOT NULL,
    student_id bigint NOT NULL
);


--
-- Name: courses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courses (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    status public.enum_courses_status DEFAULT 'active'::public.enum_courses_status
);


--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.courses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: donations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donations (
    id bigint NOT NULL,
    donor_type public.enum_donations_donor_type DEFAULT 'person'::public.enum_donations_donor_type NOT NULL,
    donor_name character varying(150),
    donor_phone character varying(15),
    kind public.enum_donations_kind NOT NULL,
    amount numeric(12,3),
    item character varying(200),
    quantity integer,
    date date NOT NULL,
    note character varying(255),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: donations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.donations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: donations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.donations_id_seq OWNED BY public.donations.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id bigint NOT NULL,
    title character varying(150) NOT NULL,
    amount numeric(12,3) NOT NULL,
    date date NOT NULL,
    note character varying(255) DEFAULT NULL::character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id bigint NOT NULL,
    label character varying(100) NOT NULL,
    head_teacher_id bigint,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    association_name character varying(150) DEFAULT 'جمعية القرآن الكريم'::character varying NOT NULL,
    school_year character varying(20) DEFAULT '2025/2026'::character varying NOT NULL,
    default_fee numeric(10,2) DEFAULT 50 NOT NULL,
    phone character varying(20),
    address character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    logo character varying(255)
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: student_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_groups (
    id bigint NOT NULL,
    student_id bigint,
    type public.enum_student_groups_type DEFAULT 'student'::public.enum_student_groups_type NOT NULL,
    name character varying(150),
    phone character varying(30),
    group_id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    year integer NOT NULL
);


--
-- Name: student_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.student_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: student_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.student_groups_id_seq OWNED BY public.student_groups.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    father_name character varying(100),
    father_phone character varying(20),
    birthdate date NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    memorized numeric(4,2) DEFAULT 0,
    is_delete boolean DEFAULT false NOT NULL
);


--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.students_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: subscription_payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_payment (
    id bigint NOT NULL,
    amount numeric(10,3) NOT NULL,
    date_payment timestamp with time zone NOT NULL,
    subscription_id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    year character varying(4) NOT NULL,
    month character varying(2) NOT NULL,
    status public.enum_subscription_payment_status DEFAULT 'part'::public.enum_subscription_payment_status NOT NULL
);


--
-- Name: subscription_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscription_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscription_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscription_payment_id_seq OWNED BY public.subscription_payment.id;


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id bigint NOT NULL,
    date date NOT NULL,
    student_id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: teacher_payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teacher_payment (
    id bigint NOT NULL,
    amount numeric(10,3) NOT NULL,
    date_payment timestamp with time zone NOT NULL,
    year character varying(4) NOT NULL,
    month character varying(2) NOT NULL,
    teacher_id bigint NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: teacher_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.teacher_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: teacher_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.teacher_payment_id_seq OWNED BY public.teacher_payment.id;


--
-- Name: teachers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teachers (
    id bigint NOT NULL,
    last_name character varying(100) NOT NULL,
    first_name character varying(100) NOT NULL,
    start_date date NOT NULL,
    phone character varying(20) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    is_delete boolean DEFAULT false NOT NULL
);


--
-- Name: teachers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.teachers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: teachers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.teachers_id_seq OWNED BY public.teachers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role public.enum_users_role DEFAULT 'supervisor'::public.enum_users_role,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    full_name character varying(255)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: BackupLogs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BackupLogs" ALTER COLUMN id SET DEFAULT nextval('public."BackupLogs_id_seq"'::regclass);


--
-- Name: GoogleTokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens" ALTER COLUMN id SET DEFAULT nextval('public."GoogleTokens_id_seq"'::regclass);


--
-- Name: absences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.absences ALTER COLUMN id SET DEFAULT nextval('public.absences_id_seq'::regclass);


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: competition_scores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competition_scores ALTER COLUMN id SET DEFAULT nextval('public.competition_scores_id_seq'::regclass);


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: donations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations ALTER COLUMN id SET DEFAULT nextval('public.donations_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: student_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_groups ALTER COLUMN id SET DEFAULT nextval('public.student_groups_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: subscription_payment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_payment ALTER COLUMN id SET DEFAULT nextval('public.subscription_payment_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: teacher_payment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_payment ALTER COLUMN id SET DEFAULT nextval('public.teacher_payment_id_seq'::regclass);


--
-- Name: teachers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teachers ALTER COLUMN id SET DEFAULT nextval('public.teachers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: BackupLogs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BackupLogs" (id, filename, size, status, uploaded_to_drive, error, "createdAt", "updatedAt") FROM stdin;
1	backup-2026-10-19T15-54-48.sql.gz	6057	success	f	\N	2026-10-19 16:54:48.016+01	2026-10-19 16:54:51.193+01
2	backup-2026-10-19T16-03-27.sql.gz	6099	success	f	\N	2026-10-19 17:03:27.916+01	2026-10-19 17:03:31.119+01
3	backup-2026-10-19T16-09-19.sql.gz	6187	success	f	\N	2026-10-19 17:09:19.04+01	2026-10-19 17:09:21.742+01
4	backup-2026-10-19T16-09-45.sql.gz	6220	success	f	\N	2026-10-19 17:09:45.729+01	2026-10-19 17:09:48.341+01
5	backup-2026-10-19T16-13-25.sql.gz	6266	success	f	\N	2026-10-19 17:13:25.262+01	2026-10-19 17:13:28.03+01
6	backup-2026-10-19T16-17-03.sql.gz	6343	success	t	\N	2026-10-19 17:17:03.997+01	2026-10-19 17:17:06.643+01
7	backup-2026-10-26T20-10-08.sql.gz	0	running	f	\N	2026-10-26 21:10:08.432+01	2026-10-26 21:10:08.432+01
\.


--
-- Data for Name: GoogleTokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GoogleTokens" (id, user_id, refresh_token, email, folder_id, last_upload_at, "createdAt", "updatedAt") FROM stdin;
2	3	9aviMp2CrrSjJ1PX.MInnwrJY8BSfBdF1EVUn8Q==.fS+hwQTm+Piefzyfr1qaQGCWoLEXWXJ8mLuZPJXA8Mq1tm7ZRop1Y45MlXSW8iKmxJGPGMfHnS85nUnUk89gX00m/X65QP9D1H8LhELpWgAwM9h+g+ExJ3fpXAh9jJGFj+vWZ3ElOA==	akrambennour3@gmail.com	1dOWoOG6c3ThrS-M2zmUcUB_-Ys_D3BpA	2026-10-19 17:17:06.639+01	2026-10-19 17:02:23.336+01	2026-10-19 17:17:06.639+01
\.


--
-- Data for Name: absences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.absences (id, student_id, date, justified, reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activities (id, name, start_date, end_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: competition_scores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.competition_scores (id, year, group_id, student_group_id, score, "createdAt", "updatedAt", student_id) FROM stdin;
1	2026	4	1	12.00	2026-10-17 22:31:11.034+01	2026-10-17 22:31:11.034+01	\N
2	2026	4	2	23.00	2026-10-17 22:31:11.034+01	2026-10-17 22:31:11.034+01	\N
3	2026	4	6	11.00	2026-10-17 22:31:11.034+01	2026-10-17 22:31:11.034+01	\N
\.


--
-- Data for Name: course_students; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.course_students (course_id, student_id) FROM stdin;
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courses (id, name, start_date, end_date, created_at, updated_at, status) FROM stdin;
\.


--
-- Data for Name: donations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donations (id, donor_type, donor_name, donor_phone, kind, amount, item, quantity, date, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, title, amount, date, note, created_at, updated_at) FROM stdin;
2	ggg	122.000	2026-10-26	\N	2026-10-26 20:34:41.622+01	2026-10-26 20:34:41.622+01
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, label, head_teacher_id, "createdAt", "updatedAt") FROM stdin;
4	الفوار 2	8	2026-10-14 20:29:29.977+01	2026-10-14 20:29:29.977+01
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, association_name, school_year, default_fee, phone, address, "createdAt", "updatedAt", logo) FROM stdin;
6	جمعية القرآن الكريم	2025/2026	50.00	12345678	El-faouar	2026-10-14 20:50:06.233+01	2026-10-18 11:04:45.469+01	/uploads/logo-1792317885454.jpeg
\.


--
-- Data for Name: student_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.student_groups (id, student_id, type, name, phone, group_id, "createdAt", "updatedAt", year) FROM stdin;
1	10	student	\N	\N	4	2026-10-17 22:14:18.791+01	2026-10-17 22:14:18.791+01	2026
2	11	student	\N	\N	4	2026-10-17 22:14:20.373+01	2026-10-17 22:14:20.373+01	2026
6	\N	stranger	taha	\N	4	2026-10-17 22:28:40.955+01	2026-10-17 22:28:40.955+01	2026
7	12	student	\N	\N	4	2027-10-17 22:53:31.71+01	2027-10-17 22:53:31.71+01	2027
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.students (id, name, father_name, father_phone, birthdate, "createdAt", "updatedAt", memorized, is_delete) FROM stdin;
10	احمد	هشام	12345678	2026-10-14	2026-10-14 20:29:43.451+01	2026-10-14 20:29:43.451+01	1.00	f
11	احمد	هشام	12345678	2026-10-14	2026-10-14 20:50:21.272+01	2026-10-14 20:50:21.272+01	0.00	f
12	hduud	ssxx	12345678	2027-10-17	2027-10-17 22:53:31.681+01	2027-10-17 22:53:31.681+01	1.00	f
\.


--
-- Data for Name: subscription_payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_payment (id, amount, date_payment, subscription_id, "createdAt", "updatedAt", year, month, status) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, date, student_id, "createdAt", "updatedAt") FROM stdin;
10	2026-10-14	11	2026-10-14 20:50:21.279+01	2026-10-14 20:50:21.279+01
11	2027-10-17	12	2027-10-17 22:53:31.755+01	2027-10-17 22:53:31.755+01
\.


--
-- Data for Name: teacher_payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teacher_payment (id, amount, date_payment, year, month, teacher_id, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teachers (id, last_name, first_name, start_date, phone, "createdAt", "updatedAt", is_delete) FROM stdin;
8	محسن	احمد	2026-10-14	12346765	2026-10-14 20:29:22.831+01	2026-10-14 20:29:22.831+01	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password, role, "createdAt", "updatedAt", full_name) FROM stdin;
3	admin	$2b$10$NY842HYSll3/GLj1wtEwIulWITP5EMNoA4XXQvc0DSqFiJBrEmGHS	admin	2026-10-14 20:28:24.982+01	2026-10-14 20:28:24.982+01	Admin
4	admin12	$2b$12$B7/9h8N7Q3QH/UG2D6iqkuqBiz7CINxtYxTgyYXYlJK6xAUTeJLQK	supervisor	2026-10-14 20:36:04.796+01	2026-10-14 21:14:16.312+01	ffff2
\.


--
-- Name: BackupLogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."BackupLogs_id_seq"', 7, true);


--
-- Name: GoogleTokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."GoogleTokens_id_seq"', 2, true);


--
-- Name: absences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.absences_id_seq', 9, true);


--
-- Name: activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activities_id_seq', 5, true);


--
-- Name: competition_scores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.competition_scores_id_seq', 3, true);


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.courses_id_seq', 10, true);


--
-- Name: donations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.donations_id_seq', 2, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_id_seq', 2, true);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.groups_id_seq', 4, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 6, true);


--
-- Name: student_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.student_groups_id_seq', 7, true);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.students_id_seq', 12, true);


--
-- Name: subscription_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscription_payment_id_seq', 21, true);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 11, true);


--
-- Name: teacher_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.teacher_payment_id_seq', 1, true);


--
-- Name: teachers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.teachers_id_seq', 8, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: BackupLogs BackupLogs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BackupLogs"
    ADD CONSTRAINT "BackupLogs_pkey" PRIMARY KEY (id);


--
-- Name: GoogleTokens GoogleTokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_pkey" PRIMARY KEY (id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key1" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key10; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key10" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key11; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key11" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key12; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key12" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key13; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key13" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key14; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key14" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key15" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key16" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key17" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key18" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key19" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key2" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key20" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key21" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key22; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key22" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key23; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key23" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key24" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key25" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key26; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key26" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key27" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key28" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key29" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key3" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key30" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key31" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key32; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key32" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key33" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key34; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key34" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key35" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key36" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key37" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key38; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key38" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key39" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key4" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key40" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key41; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key41" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key42; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key42" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key43" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key44" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key45" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key46" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key47" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key48" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key49" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key5" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key50; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key50" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key51; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key51" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key52" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key53; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key53" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key54; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key54" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key55; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key55" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key56" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key57" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key58; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key58" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key59" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key6" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key60; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key60" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key61" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key62; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key62" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key63; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key63" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key64; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key64" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key65" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key66" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key67; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key67" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key68" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key69" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key7" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key70; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key70" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key71" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key72; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key72" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key73; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key73" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key74" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key75; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key75" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key8" UNIQUE (user_id);


--
-- Name: GoogleTokens GoogleTokens_user_id_key9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GoogleTokens"
    ADD CONSTRAINT "GoogleTokens_user_id_key9" UNIQUE (user_id);


--
-- Name: absences absences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.absences
    ADD CONSTRAINT absences_pkey PRIMARY KEY (id);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: competition_scores competition_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competition_scores
    ADD CONSTRAINT competition_scores_pkey PRIMARY KEY (id);


--
-- Name: course_students course_students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.course_students
    ADD CONSTRAINT course_students_pkey PRIMARY KEY (course_id, student_id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: donations donations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT donations_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: student_groups student_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_groups
    ADD CONSTRAINT student_groups_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: subscription_payment subscription_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_payment
    ADD CONSTRAINT subscription_payment_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: teacher_payment teacher_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_payment
    ADD CONSTRAINT teacher_payment_pkey PRIMARY KEY (id);


--
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: absences_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX absences_date ON public.absences USING btree (date);


--
-- Name: absences_student_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX absences_student_id ON public.absences USING btree (student_id);


--
-- Name: absences_student_id_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX absences_student_id_date ON public.absences USING btree (student_id, date);


--
-- Name: activities_end_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activities_end_date ON public.activities USING btree (end_date);


--
-- Name: activities_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activities_name ON public.activities USING btree (name);


--
-- Name: activities_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX activities_start_date ON public.activities USING btree (start_date);


--
-- Name: idx_competition_year_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_competition_year_group ON public.competition_scores USING btree (year, group_id);


--
-- Name: student_groups_group_id_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX student_groups_group_id_year ON public.student_groups USING btree (group_id, year);


--
-- Name: student_groups_student_id_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_groups_student_id_group_id ON public.student_groups USING btree (student_id, group_id);


--
-- Name: student_groups_student_id_group_id_year; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_groups_student_id_group_id_year ON public.student_groups USING btree (student_id, group_id, year);


--
-- Name: subscription_payment_subscription_id_year_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscription_payment_subscription_id_year_month ON public.subscription_payment USING btree (subscription_id, year, month);


--
-- Name: teacher_payment_teacher_id_year_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX teacher_payment_teacher_id_year_month ON public.teacher_payment USING btree (teacher_id, year, month);


--
-- Name: uq_competition_year_member; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_competition_year_member ON public.competition_scores USING btree (year, student_group_id);


--
-- Name: absences absences_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.absences
    ADD CONSTRAINT absences_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: competition_scores competition_scores_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competition_scores
    ADD CONSTRAINT competition_scores_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: competition_scores competition_scores_student_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competition_scores
    ADD CONSTRAINT competition_scores_student_group_id_fkey FOREIGN KEY (student_group_id) REFERENCES public.student_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: competition_scores competition_scores_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.competition_scores
    ADD CONSTRAINT competition_scores_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: course_students course_students_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.course_students
    ADD CONSTRAINT course_students_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id);


--
-- Name: groups groups_head_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_head_teacher_id_fkey FOREIGN KEY (head_teacher_id) REFERENCES public.teachers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: student_groups student_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_groups
    ADD CONSTRAINT student_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: student_groups student_groups_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_groups
    ADD CONSTRAINT student_groups_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscription_payment subscription_payment_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_payment
    ADD CONSTRAINT subscription_payment_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: teacher_payment teacher_payment_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_payment
    ADD CONSTRAINT teacher_payment_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teachers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Xb4ksDJywjseMWwFgUt6UlntsyMOt1kJZzek0Nc90v6KM462yBBVi81wKffVDlr

