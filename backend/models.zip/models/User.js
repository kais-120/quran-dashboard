const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");

const User  = sequelize.define("user",{
    id:{
        type:DataTypes.BIGINT,
        primaryKey:true,
        autoIncrement:true
    },
    name:{
        type:DataTypes.STRING,
    },
    username:{
        type:DataTypes.STRING,
        allowNull:false
    },
    password:{
        type:DataTypes.STRING,
        allowNull:false
    },
    role:{
        type:DataTypes.ENUM("كاتب(ة)","مدير"),
        defaultValue:"مدير"
    },
    is_deleted : {
        type:DataTypes.BOOLEAN,
        defaultValue:false
    }
})
module.exports = User