const Absence = require("./Absence");
const Course = require("./Course");
const CourseStudent = require("./CourseStudent");
const Group = require("./Group");
const Student = require("./Student");
const StudentGroup = require("./StudentGroup");
const Subscription = require("./Subscription");
const SubscriptionPayment = require("./SubscriptionPayment");
const Teacher = require("./Teacher");

Teacher.hasMany(Group, {
  foreignKey: "head_teacher_id",
  as: "headedGroups",
});

Group.belongsTo(Teacher, {
  foreignKey: "head_teacher_id",
  as: "headTeacher",
});

Student.hasMany(StudentGroup, {
  foreignKey: "student_id",
  as: "studentGroups",
});

StudentGroup.belongsTo(Student, {
  foreignKey: "student_id",
  as: "students",
});

Group.hasMany(StudentGroup, {
  foreignKey: "group_id",
  as: "studentGroup",
});

StudentGroup.belongsTo(Group, {
  foreignKey: "group_id",
  as: "group",
});

Student.hasMany(Subscription, {
  foreignKey: "student_id",
  as: "subscriptions",
});

Subscription.belongsTo(Student, {
  foreignKey: "student_id",
  as: "student",
});

Subscription.hasMany(SubscriptionPayment, {
  foreignKey: "subscription_id",
  as: "payments",
});

SubscriptionPayment.belongsTo(Subscription, {
  foreignKey: "subscription_id",
  as: "subscription",
});

Course.belongsToMany(Student, {
  through: CourseStudent,
  foreignKey: "course_id",
  otherKey: "student_id",
  as: "students",
});

Student.belongsToMany(Course, {
  through: CourseStudent,
  foreignKey: "student_id",
  otherKey: "course_id",
  as: "courses",
});

Student.hasMany(Absence, {
  foreignKey: "student_id",
  as: "absence",
});

Absence.belongsTo(Student, {
  foreignKey: "student_id",
  as: "students",
});




module.exports = {
  Teacher,
  Group,
  Student,
  StudentGroup,
  Subscription,
  SubscriptionPayment,
  CourseStudent,
  Course
};